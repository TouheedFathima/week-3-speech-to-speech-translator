
df['check_in_month'] = df['check_in_date'].dt.month
